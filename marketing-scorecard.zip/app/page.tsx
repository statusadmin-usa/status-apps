import MarketingScorecard from "./marketing-scorecard"

export default function Home() {
  return (
    <main className="container mx-auto p-4">
      <MarketingScorecard />
    </main>
  )
}

